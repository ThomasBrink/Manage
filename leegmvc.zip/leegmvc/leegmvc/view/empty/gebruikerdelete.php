<?php
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
	<div class= "container">
		<h2>Gebruiker is succesvol verwijderd</h2>

		<a class="link" href="<?=URL?>empty/index">Terug naar home page</a>

		<br>
		<br>
	</div>
</body>
</html>