<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?= APPLICATION_TITLE ?></title>
	<script src="<?= URL ?>/js/script.js"></script>
	<link rel="stylesheet" href="<?= URL ?>/css/style.css">
</head>
<body>
<div id="container">
	<h1>Manage</h1>
</div>
